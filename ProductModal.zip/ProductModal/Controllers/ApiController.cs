﻿using Microsoft.AspNetCore.Mvc;

namespace ProductModal.Controllers
{
    public class ApiController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
